import logo from './logo.svg';
import './App.css';
import Page from './Components/Page';

function App() {
  return (
    <div className="App">
      <Page/>
    </div>
  );
}

export default App;
