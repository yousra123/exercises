import React from 'react';
import {useState} from 'react';
import '../styles/searchBarStyle.css';

function SearchBar(props) {

    return (
        <div className="box">
                <input className ="txt" type="text" placeholder="Type a number" onChange={(event)=>{props.setNumber(event.target.value)}}/>
                <div className="box-btn">
                    <i className="fa fa-search fa-lg" onClick={()=>{props.checkNumber(props.number)}}></i>
                </div>
        </div>
    );
}

export default SearchBar;