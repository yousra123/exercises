import React from 'react';
import {useState} from 'react';
import SearchBar from './SearchBar'; 
import '../styles/style.css';

function Page(props) {

    const [number,setNumber]=useState('');
    const [state,setState] = useState({boolean:true,date:''});

    const checkNumber = (n) =>{
        let number = parseFloat(n);
        if(isNaN(number)){
            alert("Invalid value");
            setState({boolean:true,date:''});
            return;
        }else{
            var todayDate = new Date();
            todayDate.setDate(todayDate.getDate() + number);
            var dd = todayDate.getDate();
            var mm = todayDate.getMonth() + 1;
            var y = todayDate.getFullYear();
            var formattedDate = dd + '/'+ mm + '/'+ y;
            setState({boolean:false,date:formattedDate});
        }
    }

    return (
        <React.Fragment>
            <h1 className="title">Convert date</h1>
            <div className="container">
                <div className="wrapper class1">
                    <SearchBar number={number} setNumber={setNumber} checkNumber={checkNumber}/>
                </div>
                <div className="wrapper datePlusN">
                    <div className="space">
                        <div style={{fontSize: "24px"}}>
                            {state.boolean ? <i className="fa fa-arrow-left fa-10x"></i> : <i className="fa fa-arrow-right fa-10x"></i> }
                        </div>
                        <div className="wrap-para">
                            {state.boolean ? <button className="buttonClick">Click on the loop</button> : <b id="para">{state.date}</b>}
                        </div>
                    </div>
                </div>
            </div>
        </React.Fragment>
    );
}

export default Page;